/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!****************************************!*\
  !*** ./src/external/chatPlayGround.js ***!
  \****************************************/
function createBanner() {
  const banner = document.createElement('div');

  banner.innerHTML = `
    <a
      id="chatplayground-banner"
      style="display: flex;align-items: center;width: 350px;height: fit-content;padding: 10px;background-color: #fff;border: 1px solid #ccc;color: #222;border-radius: 7px;box-shadow: 1px 1px 5px #e1e1e1;transform: scale(1.15);"
      href="https://chatplayground.ai"
      target="_blank"
    >
      <div>
        <img src="https://app.chatplayground.ai/icon.png" style="width: 40px;height: 40px;margin-right: 10px;" />
      </div>

      <div>
        <p style="margin: 0; font-size: 0.8rem;font-weight: 800;">ChatPlayground.ai</p>
        <p style="margin: 0;color: #555;">
          Compare Multiple AI Chatbots for the Best Response

          <span style="color: rgb(50, 104, 206);margin-left: 5px;text-decoration: underline;">Get Started</span>
        </p>
      </div>
    </a>
  `;

  // Append the banner to the body
  if(document.querySelector(".kp-wholepage.kp-wholepage-osrp.HSryR.EyBRub")) {
    banner.style.marginBottom = "1.5rem";
    return document.querySelector(".kp-wholepage.kp-wholepage-osrp.HSryR.EyBRub").prepend(banner);
  }

  if(document.querySelector(".TzHB6b.Hwkikb.WY0eLb.LMRCfc.EqrSYc")) {
    banner.style.marginBottom = "1.5rem";
    return document.querySelector(".TzHB6b.Hwkikb.WY0eLb.LMRCfc.EqrSYc").prepend(banner);
  }

  if(document.querySelector(".osrp-blk")) {
    banner.style.marginBottom = "1.5rem";
    banner.style.display = "flex";
    banner.style.justifyContent = "center";

    return document.querySelector(".osrp-blk").prepend(banner);
  }

  if(document.querySelector(".TQc1id.k5T88b"))
    return document.querySelector(".TQc1id.k5T88b").appendChild(banner);

  if(document.querySelector(".GyAeWb")) {
    banner.style.marginTop = "1rem";
    return document.querySelector(".GyAeWb").appendChild(banner);
  }

}

createBanner();
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hhdF9wbGF5X2dyb3VuZC5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQixvQkFBb0IsYUFBYSxvQkFBb0IsY0FBYyx1QkFBdUIsdUJBQXVCLFlBQVksbUJBQW1CLGdDQUFnQyx1QkFBdUI7QUFDbE87QUFDQTtBQUNBO0FBQ0E7QUFDQSw2RUFBNkUsYUFBYSxtQkFBbUI7QUFDN0c7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCLGtCQUFrQixpQkFBaUI7QUFDaEUsNEJBQTRCLFlBQVk7QUFDeEM7QUFDQTtBQUNBLGdEQUFnRCxpQkFBaUIsMkJBQTJCO0FBQzVGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZSIsInNvdXJjZXMiOlsid2VicGFjazovL01va2t1Ly4vc3JjL2V4dGVybmFsL2NoYXRQbGF5R3JvdW5kLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImZ1bmN0aW9uIGNyZWF0ZUJhbm5lcigpIHtcclxuICBjb25zdCBiYW5uZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuXHJcbiAgYmFubmVyLmlubmVySFRNTCA9IGBcclxuICAgIDxhXHJcbiAgICAgIGlkPVwiY2hhdHBsYXlncm91bmQtYmFubmVyXCJcclxuICAgICAgc3R5bGU9XCJkaXNwbGF5OiBmbGV4O2FsaWduLWl0ZW1zOiBjZW50ZXI7d2lkdGg6IDM1MHB4O2hlaWdodDogZml0LWNvbnRlbnQ7cGFkZGluZzogMTBweDtiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO2JvcmRlcjogMXB4IHNvbGlkICNjY2M7Y29sb3I6ICMyMjI7Ym9yZGVyLXJhZGl1czogN3B4O2JveC1zaGFkb3c6IDFweCAxcHggNXB4ICNlMWUxZTE7dHJhbnNmb3JtOiBzY2FsZSgxLjE1KTtcIlxyXG4gICAgICBocmVmPVwiaHR0cHM6Ly9jaGF0cGxheWdyb3VuZC5haVwiXHJcbiAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICA+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGltZyBzcmM9XCJodHRwczovL2FwcC5jaGF0cGxheWdyb3VuZC5haS9pY29uLnBuZ1wiIHN0eWxlPVwid2lkdGg6IDQwcHg7aGVpZ2h0OiA0MHB4O21hcmdpbi1yaWdodDogMTBweDtcIiAvPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPHAgc3R5bGU9XCJtYXJnaW46IDA7IGZvbnQtc2l6ZTogMC44cmVtO2ZvbnQtd2VpZ2h0OiA4MDA7XCI+Q2hhdFBsYXlncm91bmQuYWk8L3A+XHJcbiAgICAgICAgPHAgc3R5bGU9XCJtYXJnaW46IDA7Y29sb3I6ICM1NTU7XCI+XHJcbiAgICAgICAgICBDb21wYXJlIE11bHRpcGxlIEFJIENoYXRib3RzIGZvciB0aGUgQmVzdCBSZXNwb25zZVxyXG5cclxuICAgICAgICAgIDxzcGFuIHN0eWxlPVwiY29sb3I6IHJnYig1MCwgMTA0LCAyMDYpO21hcmdpbi1sZWZ0OiA1cHg7dGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XCI+R2V0IFN0YXJ0ZWQ8L3NwYW4+XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvYT5cclxuICBgO1xyXG5cclxuICAvLyBBcHBlbmQgdGhlIGJhbm5lciB0byB0aGUgYm9keVxyXG4gIGlmKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIua3Atd2hvbGVwYWdlLmtwLXdob2xlcGFnZS1vc3JwLkhTcnlSLkV5QlJ1YlwiKSkge1xyXG4gICAgYmFubmVyLnN0eWxlLm1hcmdpbkJvdHRvbSA9IFwiMS41cmVtXCI7XHJcbiAgICByZXR1cm4gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5rcC13aG9sZXBhZ2Uua3Atd2hvbGVwYWdlLW9zcnAuSFNyeVIuRXlCUnViXCIpLnByZXBlbmQoYmFubmVyKTtcclxuICB9XHJcblxyXG4gIGlmKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIuVHpIQjZiLkh3a2lrYi5XWTBlTGIuTE1SQ2ZjLkVxclNZY1wiKSkge1xyXG4gICAgYmFubmVyLnN0eWxlLm1hcmdpbkJvdHRvbSA9IFwiMS41cmVtXCI7XHJcbiAgICByZXR1cm4gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5UekhCNmIuSHdraWtiLldZMGVMYi5MTVJDZmMuRXFyU1ljXCIpLnByZXBlbmQoYmFubmVyKTtcclxuICB9XHJcblxyXG4gIGlmKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIub3NycC1ibGtcIikpIHtcclxuICAgIGJhbm5lci5zdHlsZS5tYXJnaW5Cb3R0b20gPSBcIjEuNXJlbVwiO1xyXG4gICAgYmFubmVyLnN0eWxlLmRpc3BsYXkgPSBcImZsZXhcIjtcclxuICAgIGJhbm5lci5zdHlsZS5qdXN0aWZ5Q29udGVudCA9IFwiY2VudGVyXCI7XHJcblxyXG4gICAgcmV0dXJuIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIub3NycC1ibGtcIikucHJlcGVuZChiYW5uZXIpO1xyXG4gIH1cclxuXHJcbiAgaWYoZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5UUWMxaWQuazVUODhiXCIpKVxyXG4gICAgcmV0dXJuIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIuVFFjMWlkLms1VDg4YlwiKS5hcHBlbmRDaGlsZChiYW5uZXIpO1xyXG5cclxuICBpZihkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLkd5QWVXYlwiKSkge1xyXG4gICAgYmFubmVyLnN0eWxlLm1hcmdpblRvcCA9IFwiMXJlbVwiO1xyXG4gICAgcmV0dXJuIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIuR3lBZVdiXCIpLmFwcGVuZENoaWxkKGJhbm5lcik7XHJcbiAgfVxyXG5cclxufVxyXG5cclxuY3JlYXRlQmFubmVyKCk7Il0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9